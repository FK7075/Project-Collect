package filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.Admin;
import xfl.fk.servlet.LuckyFilter;

public class AdminLoginFilter extends LuckyFilter {

	@Override
	public void isRelease(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		String uri=request.getRequestURI();
		if(uri.contains("login.xfl")||uri.contains("admin_Login.jsp")||uri.contains("error-404.jsp")||uri.contains("error-500.jsp")) {
			chain.doFilter(request, response);
		}else {
			Admin admin=(Admin) request.getSession().getAttribute("admin");
			if(admin!=null)
				chain.doFilter(request, response);
			else
				response.sendRedirect("./admin_Login.jsp");
			
		}

	}

}
