package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import pojo.Consigness;
import pojo.Orders;
import pojo.ShoppCart;
import pojo.Stort;
import pojo.User;
import service.IUserService;
import util.LucyUtil;
import xfl.fk.annotation.Autowired;
import xfl.fk.annotation.Controller;
import xfl.fk.annotation.RequestMapping;
import xfl.fk.servlet.Model;

@Controller(prefix="/User/pages/",suffix=".jsp")
@RequestMapping("/User/pages")
public class UserController {

	@Autowired
	private IUserService useS;
	
	
	@RequestMapping("/homeContent")
	public String homeContent(Model model) {
		model.setRequestAttribute("booklist", useS.getPopularBook());
		model.setRequestAttribute("noteslist", useS.getNotes());
		model.setRequestAttribute("stortlist", useS.getShowStort());
		List<Stort> stortlist=useS.getShowStort();
		model.setRequestAttribute("stortlist1", useS.allStort());
		model.setSessionAttribute("allstort", useS.allStort());
		model.setRequestAttribute("showStort1", useS.showBookByStort(stortlist.get(0).getStid()));
		model.setRequestAttribute("showStort2", useS.showBookByStort(stortlist.get(1).getStid()));
		model.setRequestAttribute("showStort3", useS.showBookByStort(stortlist.get(2).getStid()));
		model.setRequestAttribute("showStort4", useS.showBookByStort(stortlist.get(3).getStid()));
		return "user_index";
	}
	
	// ��ҳ��ȡ�����鱾��Ϣ
	@RequestMapping("/allBook")
	public String allBook(Model model) {
		LucyUtil lucy=new LucyUtil();
		int page=lucy.getPage("pages");
		model.setRequestAttribute("page", page);
		model.setRequestAttribute("booklist",useS.showAllBook(page));
		return "user_BookList";
	}
	
	// ��ҳ��ʾ��������
	@RequestMapping("/allAuthor")
	public String allAuthor(Model model) {
		LucyUtil lucy=new LucyUtil();
		int page=lucy.getPage("pages");
		model.setRequestAttribute("page", page);
		model.setRequestAttribute("authorlist",useS.showAllAuthor(page));
		return "user_AuthorList";
	}
	
	//�õ����������µ�����ͼ��
	@RequestMapping("/authorToBooks")
	public String authorToBooks(Model model,int id) {
		model.setRequestAttribute("booklist",useS.autToBooks(id));
		return "user_AutToBooks";
	}
	
	// ��������
	@RequestMapping("/autDetail")
	public String autDetail(Model model,int id) {
		model.setRequestAttribute("author",useS.getAuthorById(id));
		return "user_AutDetail";
	}
	
	// �õ��������µ�����ͼ��
	@RequestMapping("/stortToBooks")
	public String stortToBooks(Model model,int id) {
		model.setRequestAttribute("booklist",useS.stoToBooks(id));
		return "user_StoToBooks";
	}
	
	// �û���¼
	@RequestMapping("/login")
	public String login(Model model,String uName,String uPass,String checkbox ) {
		int maxAge=0;
		if(checkbox != null)
			maxAge=60*60*3;
		model.setCookieContent("LB_userID", uName, maxAge);
		model.setCookieContent("LB_userPass", uPass, maxAge);
		User user = new User();  
		user.setuName(uName);
		user.setuPassword(uPass);
		if (useS.login(user) != null) {
			model.setSessionAttribute("user", useS.login(user));
			return "forward:homeContent.xfl";
		} else {
			model.setRequestAttribute("isOk", "isOk");
			return "user_Login";
		}
	}
	
	// �û�ע��
	@RequestMapping("/register")
	public String register(Model model,User user) {
		user.setChangenum(6);
		if (useS.register(user)) {
			model.setRequestAttribute("isOK", 0);//ע��ɹ�
		} else {
			model.setRequestAttribute("isOK", 1);//ע��ʧ�ܣ��û����Ѵ���
		}
		return "user_Register";
	}
	
	// ע����¼
	@RequestMapping("/loginOut")
	public String loginOut(Model model) {
		model.getSession().removeAttribute("user");
		return "forward:homeContent.xfl";
	}
	
	// �ջ����б�
	@RequestMapping("/myConsigness")
	public String myConsigness(Model model) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			model.setRequestAttribute("conslist", useS.getConsigness(u.getUid()));
			return "myConsigness";
		} else
			return "user_Login";
	}
	
	// �����ջ��˲�����ΪĬ��
	@RequestMapping("/addConsigness")
	public String addConsigness(Model model,Consigness con) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			con.setUid(u.getUid());
			useS.save(con);
			con=(Consigness) useS.getList(con).get(0);
			u.setMyCons(con.getConsid());
			useS.update(u);
			return "forward:myConsigness.xfl";
		} else
			return "user_Login";
	}
	
	// ɾ���ջ���
	@RequestMapping("/delConsigness")
	public String delConsigness(int id) {
		useS.del(Consigness.class, id);
		return "forward:myConsigness.xfl";
	}
	
	// �޸��ջ�������׼��
	@RequestMapping("/updConsigness")
	public String updConsigness(Model model,int id) {
		model.setRequestAttribute("cons", useS.getOne(Consigness.class,id));
		return "updConsigness";
	}
	
	// �����ջ�����Ϣ
	@RequestMapping("/updateConsigness")
	public String updateConsigness(Consigness con) {
		useS.update(con);//ִ�и��²���
		return "forward:updConsigness.xfl?id="+con.getConsid();
	}
	
	// ����Ĭ���ջ���
	@RequestMapping("/consToUser")
	public String consToUser(Model model,int id) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			u.setMyCons(id);
			useS.update(u);
			return "forward:myConsigness.xfl";
		} else
			return "user_Login";
	}
	
	// ���ﳵ��Ϣ
	@RequestMapping("/shoppingCart")
	public String shoppingCart(Model model) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			model.setRequestAttribute("booklist", useS.shoppCart(u.getUid()));
			return "shoppingcart";
		} else {
			return "user_Login";
		}
	}
	
	// ����ѡ�л�ѡ
	@RequestMapping("/changeState")
	public String changeState(int id) {
		useS.changeState(id);
		return "forward:shoppingCart.xfl";
	}
	
	// ȫѡ�ͷ�ѡ
	@RequestMapping("/allChoose")
	public String allChoose(String st) {
		if ("1".equals(st))//st=1Ϊȫѡ����
			st = "��ѡ��";
		if ("2".equals(st))//st=2Ϊȫ��ѡ����
			st = "δѡ��";
		useS.allChoose(st);//ִ��ѡ�����
		return "forward:shoppingCart.xfl";
	}
	
	// ɾ�����ﳵ�е���Ʒ
	@RequestMapping("/delGoods")
	public String delGoods(int id) {
		useS.del(ShoppCart.class, id);
		return "forward:shoppingCart.xfl";
	}
	
	// ���ﳵ�����ɶ���
	@RequestMapping("/cartToOrder")
	public String cartToOrder(Model model,HttpServletRequest request) {
		HttpSession session=model.getSession();
		int[] numbers = toInt((String[]) request.getParameterValues("number"));
		int[] shoppids = toInt((String[]) request.getParameterValues("shoppid"));
		String beizhu = request.getParameter("beizhu");
		User u = (User) session.getAttribute("user");
		if (useS.cartToOrder(u, shoppids, numbers, beizhu)) {//���ɶ���
			return "forward:myOrders.xfl";
		} else {
			return "isNO";
		}
	}
	
	// ��֧������
	@RequestMapping("/myOrders")
	public String myOrders(Model model) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			model.setRequestAttribute("ordtlist", useS.myOrders(u.getUid()));
			return "user_Orders";
		} else {
			return "user_Login";
		}
	}
	
	//ģ�⸶��
	@RequestMapping("/payOrder")
	public String payOrder(int ordid) {
		Orders ord = (Orders) useS.getOne(Orders.class, ordid);
		ord.setOrdPayState("�Ѹ���");
		useS.update(ord);
		return "forward:payDetail.xfl";
	}
	
	
	
	// �Ѹ���δ��������
	@RequestMapping("/payDetail")
	public String payDetail(Model model) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");//ȡ��session���е�user����
			model.setRequestAttribute("ordtlist", useS.payDetail(u.getUid()));
			return "ser_PayOrders";
		} else {
			return "page:user_Login";//�ض��򵽵�¼ҳ��
		}
	}
	
	//ȡ������
	@RequestMapping("/cancelOrder")
	public String cancelOrder(int ordid) {
		useS.cancelOrder(ordid);
		return "forward:myOrders.xfl";
	}
	
	// ��ʾ��ϸ��Ϣ
	@RequestMapping("/ordDetail")
	public String ordDetail(Model model,int ordid) {
		Orders or = (Orders) useS.getOne(Orders.class, ordid);
		model.setRequestAttribute("cons", useS.getOne(Consigness.class, or.getConsid()));
		model.setRequestAttribute("booklist", useS.ordDetail(or.getOrdid()));
		model.setRequestAttribute("ordid", ordid);
		return "user_OrdDetail";
	}
	
	// �����ջ���ҳ�����Ϣ׼��
	@RequestMapping("/changeCons")
	public String changeCons(Model model,int ord) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			Consigness con = new Consigness();
			con.setUid(u.getUid());
			model.setRequestAttribute("conslist", useS.getList(con));
			model.setRequestAttribute("id", ord);
			return "user_OrderCons";
		} else
			return "user_Login";//�ض��򵽵�¼ҳ��
	}
	
	// �����ջ��˲���
	@RequestMapping("/changeConsigess")
	public String changeConsigess(int cosid,int ordid) {
		Orders ord = (Orders) useS.getOne(Orders.class, ordid);
		ord.setConsid(cosid);
		useS.update(ord);
		return "forward:ordDetail.xfl?ordid="+ordid;
	}
	
	//����ɶ���
	@RequestMapping("/sendOrder")
	public String sendOrder(Model model) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			model.setRequestAttribute("ordtlist", useS.sendOrder(u.getUid()));
			return "user_completeOrders";
		} else {
			return "page:user_Login";//�ض��򵽵�¼ҳ��
		}
	}
	
	//�鿴������ϸ
	@RequestMapping("/payOrdDetail")
	public String payOrdDetail(Model model,int ordid) {
		Orders or = (Orders) useS.getOne(Orders.class, ordid);//�õ�������Ϣ
		model.setRequestAttribute("cons", useS.getOne(Consigness.class, or.getConsid()));
		model.setRequestAttribute("booklist", useS.payOrdDetail(or.getOrdid()));
		return "user_payOrderDetail";
	}
	
	//���������ϲ�ѯͼ�飨����+����+���ͣ�
	@RequestMapping("/searchBook")
	public String searchBook(Model model,String bName,String aName,String sName) {
		model.setRequestAttribute("booklist",useS.search(bName, aName, sName));
		return "user_searchBooks";
	}
	
	// ����Ʒ���ӵ����ﳵ
	@RequestMapping("/addToCart")
	public String addToCart(Model model,int bid) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u = (User) session.getAttribute("user");
			if (useS.addToCart(u.getUid(), bid)) {
				return "forward:allBook.xfl";
			} else {
				return "isNO";
			}
		} else {
			return "page:user_Login";
		}
	}
	
	
	// �޸��û���Ϣ
	@RequestMapping("/setUserInfo")
	public String setUserInfo(Model model,String uSex,String uTel,int fy) {
		HttpSession session=model.getSession();
		if (session.getAttribute("user") != null) {
			User u1 = (User) session.getAttribute("user");
			u1.setuSex(uSex);
			u1.setuTel(uTel);
			u1.setChangenum(fy);
			useS.update(u1);
			session.setAttribute("user", u1);
			return "user_userInfo";
		} else {
			return "user_Login";
		}
	}
	
	// �û��޸�����
	@RequestMapping("/newPassword")
	public String newPassword(Model model,String uSex) {
		HttpSession session=model.getSession();
		User u1 = (User) session.getAttribute("user");
		u1.setuPassword(uSex);
		useS.update(u1);
		session.removeAttribute("user");
		return "user_Login";
	}
	
	// ���ַ�������ת��Ϊint����
	private int[] toInt(String[] s) {
		int[] n = new int[s.length];
		for (int i = 0; i < s.length; i++) {
			n[i] = Integer.parseInt(s[i]);
		}
		return n;
	}
	
	
}
