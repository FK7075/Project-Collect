package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import pojo.Admin;
import pojo.Author;
import pojo.Book;
import pojo.Notes;
import pojo.Orders;
import pojo.Stort;
import pojo.User;
import service.IAdminService;
import util.BookInfo;
import util.LucyUtil;
import util.OrderInfo;
import xfl.fk.annotation.Autowired;
import xfl.fk.annotation.Controller;
import xfl.fk.annotation.Download;
import xfl.fk.annotation.RequestMapping;
import xfl.fk.annotation.Upload;
import xfl.fk.join.Paging;
import xfl.fk.servlet.Model;

@Controller(prefix="/Admin/pages/",suffix=".jsp")
@RequestMapping("/Admin/pages")
public class AdminController {
	
	@Autowired
	private IAdminService admS;
	
	//管理员登录，以及记住密码
	@RequestMapping("/login")
	public String login(Model model, String username,String password,String checkbox ) {
		int maxAge=0;
		if(checkbox != null)
			maxAge=60*60*3;
		model.setCookieContent("LB_adminID", username, maxAge);
		model.setCookieContent("LB_adminPass", password, maxAge);
		Admin admin=new Admin();
		admin.setAdmName(username);
		admin.setAdmPassword(password);
		if(admS.islogin(admin)==null) {
			model.setRequestAttribute("isOk", "on");
			return "admin_Login";
		}else {
			model.setSessionAttribute("admin", admS.islogin(admin));
			return "forward:statistical.xfl";
		}
		
	}
	
	//管理员后台首页，首页展示书店的各项数据
	@RequestMapping("/statistical")
	public String statistical(HttpServletRequest request) {
		List<Object> lolist=admS.statistical();
		request.setAttribute("lolist", lolist);
		return "admin_statistical";
	}
	
	//分页展示所有图书
	@RequestMapping("/showBook")
	public String showBook(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page=lucy.getPage("pages");
		Paging<BookInfo> paging =new Paging<>(admS::showBook);
		request.setAttribute("booklist", paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_BookList";
	}
	
	//删除书本，以及图片
	@RequestMapping("/delBook")
	public String delBook(Model model,int bid) {
		String path=model.getRealPath("");
		admS.delBook(bid, path);
		return "forward:showBook.xfl";
	}
	
	//为添加图书做数据准备
	@RequestMapping("/showAddBook")
	public String showAddBook(HttpServletRequest request) {
		List<List<?>> list=admS.showAddBook();
		request.setAttribute("autlist",list.get(0));
		request.setAttribute("stlist",list.get(1));
		return "admin_AddBook";
	}
	//添加书本，文件上传
	@RequestMapping("/addBook")
	@Upload(names="bPhoto",filePath="Lucy/books")
	public String addBook(Book book) {
		book.setbPhoto("Lucy/books/"+book.getbPhoto());
		book.setbSales(0);
		admS.addBook(book);
		return "forward:showBook.xfl";
	}
	
	//查看书本详情
	@RequestMapping("/getBook")
	public String getBook(HttpServletRequest request,int bid) {
		request.setAttribute("bookInfo",admS.getBook(bid));
		return "BookInfo";
	}
	
	//书本修改页面的数据准备
	@RequestMapping("/showUpdBook")
	public String showUpdBook(HttpServletRequest request,int bid) {
		request.setAttribute("book",admS.getOneBook(bid));
		return "admin_updateBook";
	}
	
	//修改书本信息
	@RequestMapping("/updBook")
	public String updBook(Book book) {
		admS.updBook(book);
		return "forward:showUpdBook.xfl?bid="+book.getBid();
	}
	
	//库存警报——分页
	@RequestMapping("/inveAlarm")
	public String inveAlarm(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		int page=lucy.getPage("pages");
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		Paging<BookInfo> paging=new Paging<>(()->admS.inveAlarm(sessionAdmin.getInventory()));
		request.setAttribute("booklist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "InventoryAlarm";
	}
	
	//修改库存的数据准备
	@RequestMapping("/showInveAlarm")
	public String showInveAlarm(HttpServletRequest request,int bid) {
		request.setAttribute("book", admS.getBook(bid));
		return "admin_upBook";
	}
	
	//修改库存
	@RequestMapping("/updInveAlarm")
	public String updInveAlarm(Book book) {
		admS.updBook(book);
		return "forward:showInveAlarm.xfl?bid="+book.getBid();
	}
	
	//显示设置页的数据准备
	@RequestMapping("/showSetting")
	public String showSetting(HttpServletRequest request) {
		request.setAttribute("admCfg",request.getSession().getAttribute("admin"));
		return "setting";
	}
	
	//更新设置
	@RequestMapping("/setting")
	public String setting(HttpServletRequest request,int bookStort,int bookStore) {
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		sessionAdmin.setInventory(bookStort);
		sessionAdmin.setPagesize(bookStore);
		admS.updAdmin(sessionAdmin);
		request.setAttribute("settingIsOk", 1);
		return "forward:showSetting.xfl";
	}
	
	//分页——类型
	@RequestMapping("/showStort")
	public String showStort(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page=lucy.getPage("pages");
		Paging<Stort> paging=new Paging<>(admS::showStort);
		request.setAttribute("stortlist", paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_StortList";
	}
	
	//删除一个类型以及旗下的所有书本
	@RequestMapping("/delStort")
	public String delStort(int stid) {
		admS.del(Stort.class, stid);
		return "forward:showStort.xfl?pages=1";
	}
	
	//增加一个类型
	@RequestMapping("/addStort")
	public String addStort(HttpServletRequest request,String bookName) {
		if(admS.addStortIsOk(bookName))
			request.setAttribute("IsOk", 1);
		else
			request.setAttribute("IsOk", 0);
		return "admin_AddStort";
	}
	
	//类型修改前的数据准备
	@RequestMapping("/showUpdStrot")
	public String showUpdStrot(HttpServletRequest request,int stid) {
		Stort st=(Stort) admS.getOne(Stort.class, stid);
		request.setAttribute("stort",st);
		return "admin_UpStort";
	}
	
	//类型修改
	@RequestMapping("/updStort")
	public String updStort(int tableid,String bookName) {
		Stort st=new Stort();
		st.setStid(tableid);
		st.setStName(bookName);
		admS.upd(st);
		return "forward:showUpdStrot.xfl?stid="+tableid;
	}
	
	//是否展示类型（单击'✔'变为'__',单击'__'变为'✔'）
	@RequestMapping("/isShowStrot")
	public String isShowStrot(int stid) {
		admS.isShowStrot(stid);
		return "forward:showStort.xfl";
	}
	
	//分页——作者
	@RequestMapping("/showAuthor")
	public String showAuthor(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page=lucy.getPage("pages");
		Paging<Author> paging=new Paging<>(admS::showAuthor);
		request.setAttribute("authorlist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_AuthorList";
	}
	
	//添加一名作者_图片上传
	@RequestMapping("/addAuthor")
	@Upload(names="autPor",filePath="Lucy/authors")
	public String addAuthor(Author author) {
		author.setAutPor("Lucy/authors/"+author.getAutPor());
		admS.add(author);
		return "forward:showAuthor.xfl";
	}
	
	//删除作者，以及旗下的所有书本
	@RequestMapping("/delAuthor")
	public String delAuthor(HttpServletRequest request,int id) {
		String path=request.getServletContext().getRealPath("");
		admS.delAuthor(id, path);
		return "forward:showAuthor.xfl";
	}
	
	//查看作者详细信息
	@RequestMapping("/getOneAuthor")
	public String getOneAuthor(HttpServletRequest request,int id) {
		request.setAttribute("author",admS.getOne(Author.class, id));
		return "admin_AuthorInfo";
	}
	
	//作者更新前的信息准备
	@RequestMapping("/showUpdAuthor")
	public String showUpdAuthor(HttpServletRequest request,int id) {
		request.setAttribute("author",admS.getOne(Author.class, id));
		return "admin_UpdateAuthor";
	}
	
	//作者信息更新
	@RequestMapping("/updAuthor")
	public String updAuthor(Author author) {
		admS.upd(author);
		return "forward:showUpdAuthor.xfl?id="+author.getAutid();
	}
	
	//所有美文
	@RequestMapping("/showNotes")
	public String showNotes(HttpServletRequest request) {
		request.setAttribute("noteslist",admS.getList(new Notes()));
		return "admin_notes";
	}
	
	//添加美文
	@RequestMapping("/addNotes")
	public String addNotes(Notes notes) {
		admS.add(notes);
		return "forward:showNotes.xfl";
	}
	
	//删除两页美文
	@RequestMapping("/delNotes")
	public String delNotes(int id) {
		admS.del(Notes.class, id);
		return "forward:showNotes.xfl";
	}
	
	//修改美文前的数据准备
	@RequestMapping("/showUpdNotes")
	public String showUpdNotes(HttpServletRequest request,int id) {
		request.setAttribute("notes",admS.getOne(Notes.class, id));
		return "admin_updateNotes";
	}
	
	//修改美文
	@RequestMapping("/updNotes")
	public String updNotes(Notes notes) {
		admS.upd(notes);
		return "forward:showUpdNotes.xfl?id="+notes.getBufid();
	}
	
	//分页-所有订单
	@RequestMapping("/showAllOrder")
	public String showAllOrder(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page=lucy.getPage("pages");
		Paging<OrderInfo> paging=new Paging<>(admS::showOrder);
		request.setAttribute("orderInfolist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_OrderList";
	}
	
	//查看明细
	@RequestMapping("/showDetail")
	public String showDetail(HttpServletRequest request,int id) {
		request.setAttribute("detailInfolist",admS.showDetail(id));
		return "admin_DetailList";
	}
	
	//从服务器中下载订单Excel表格
	@RequestMapping("/download")
	@Download(name="filename",filePath="")
	public void download(HttpServletRequest request) throws IOException {
		String path=request.getServletContext().getRealPath("/");
		admS.excel(path);
	}
	
	//分页--未付款订单
	@RequestMapping("/noPayment")
	public String noPayment(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page=lucy.getPage("pages");
		Paging<OrderInfo> paging=new Paging<>(admS::noPayment);
		request.setAttribute("orderInfolist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_NoPayment";
	}
	
	//删除一些长期不付款的订单
	@RequestMapping("/delOrder")
	public String delOrder(int id) {
		admS.delOrder(id);
		return "forward:noPayment.xfl";
	}
	
	//分页--已付款但未发货的订单
	@RequestMapping("/noDelivery")
	public String noDelivery(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page=lucy.getPage("pages");
		Paging<OrderInfo> paging=new Paging<>(admS::noDelivery);
		request.setAttribute("orderInfolist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_NoDelivery";
	}
	
	//发货
	@RequestMapping("/delivery")
	public String delivery(int id) {
		Orders orders=(Orders) admS.getOne(Orders.class, id);
		orders.setOrdSendState("已发货");
		admS.upd(orders);
		return "forward:noDelivery.xfl";
	}
	
	//注销登录
	@RequestMapping("/loginOut")
	public String loginOut(HttpServletRequest request) {
		request.getSession().removeAttribute("admin");
		return "admin_Login";
	}
	
	//管理员修改密码
	@RequestMapping("/admNewPassword")
	public String admNewPassword(HttpServletRequest request,String uSex) {
		Admin admin=(Admin) request.getSession().getAttribute("admin");
		admin.setAdmPassword(uSex);
		admS.upd(admin);
		return "forward:loginOut.xfl";
	}
	
	//分页--用户
	@RequestMapping("/allUser")
	public String allUser(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page = lucy.getPage("pages");
		Paging<User> paging=new Paging<>(admS::allUser);
		request.setAttribute("userlist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_userList";
	}
	
	//删除一名用户
	@RequestMapping("/delUser")
	public String delUser(int id) {
		admS.del(User.class, id);
		return "forward:allUser.xfl";
	}
	
	//重置用户密码为123456
	@RequestMapping("/resetPass")
	public String resetPass(int id) {
		User user=(User) admS.getOne(User.class, id);
		user.setuPassword("123456");
		admS.upd(user);
		return "forward:allUser.xfl";
	}
	
	//分页--管理员
	@RequestMapping("/allAdmin")
	public String allAdmin(HttpServletRequest request) {
		LucyUtil lucy=new LucyUtil();
		Admin sessionAdmin=(Admin) request.getSession().getAttribute("admin");
		int page = lucy.getPage("pages");
		Paging<Admin> paging=new Paging<>(admS::allAdmin);
		request.setAttribute("adminlist",paging.getPageList(page, sessionAdmin.getPagesize()));
		if (page == paging.getPagenum())
			request.setAttribute("fk", 1);
		request.setAttribute("page", page);
		return "admin_adminList";
	}
	
	//删除一名管理员
	@RequestMapping("/delAdmin")
	public String delAdmin(HttpServletRequest request,int id) {
		if(id!=1&&id!=2) {
			String path=request.getServletContext().getRealPath("");
			admS.delAdmin(id, path);
		}else {
			request.setAttribute("fk1", 1);
		}
		return "forward:allAdmin.xfl";
	}
	
	//重置管理员密码为123456
	@RequestMapping("/resetAdmin")
	public String resetAdmin(HttpServletRequest request,int id) {
		if(id!=1&&id!=2) {
			Admin admin=(Admin) admS.getOne(Admin.class, id);
			admin.setAdmPassword("123456");
			admS.upd(admin);
		}else {
			request.setAttribute("xfl1", 1);
		}
		return "forward:allAdmin.xfl";
	}
	
	//添加管理员以及图片上传
	@RequestMapping("/addAdmin")
	@Upload(names="admPor",filePath="Lucy/admins")
	public String addAdmin(HttpServletRequest request,Admin admin) {
		admin.setAdmPor("Lucy/admins/"+admin.getAdmPor());
		admin.setInventory(100);
		admin.setPagesize(4);
		if(admS.addAdmin(admin)) {
			request.setAttribute("addIsOk", 1);
		}else{
			request.setAttribute("addIsOk", 0);
		}
		return "forward:statistical.xfl";
	}
	
	//根据书名，类型名，作者姓名，作者国籍，作者性别，作者出生日期查作者
	@RequestMapping("/retrieveAuthor")
	public String retrieveAuthor(HttpServletRequest request,String ssName) {
		request.setAttribute("authorlist", admS.retrieveAuthor(ssName));
		request.setAttribute("ssName",ssName);
		return "admin_AuthorList";
	}
	
	//根据书名，作者，类型查书本
	@RequestMapping("/retrieveBook")
	public String retrieveBook(HttpServletRequest request,String ssName) {
		request.setAttribute("booklist", admS.retrieveBook(ssName));
		request.setAttribute("ssName",ssName);
		return "admin_BookList";
	}

}
