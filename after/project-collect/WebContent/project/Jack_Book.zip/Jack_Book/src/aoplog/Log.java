package aoplog;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import pojo.Admin;
import pojo.User;
import util.FileWrite;
import xfl.fk.annotation.Expand;
import xfl.fk.servlet.LuckyWebContext;

@Expand
public class Log {
	
	@Expand("log_u")
	public void logUser(String info) throws IOException {
		HttpServletRequest request=LuckyWebContext.getCurrentContext().getRequest();
		User user=(User) request.getSession().getAttribute("user");
		String path=request.getServletContext().getRealPath("");
		FileWrite file=new FileWrite(path);
		if(user!=null) {
			file.logWrite("�û�#"+user.getuName()+"#�� "+getTime()+" ʹ����"+info+".\n");
		}
	}
	
	@Expand("log_a")
	public void logAdmin(String info) throws IOException {
		HttpServletRequest request=LuckyWebContext.getCurrentContext().getRequest();
		Admin admin=(Admin) request.getSession().getAttribute("admin");
		String path=request.getServletContext().getRealPath("");
		FileWrite file=new FileWrite(path);
		if(admin!=null) {
			file.logWrite("����Ա#"+admin.getAdmName()+"#�� "+getTime()+" ʹ����"+info+".\n");
		}
	}
	
	@Expand("admin_del")
	public void delLog(int id,String op,String info) throws IOException {
		HttpServletRequest request=LuckyWebContext.getCurrentContext().getRequest();
		Admin admin=(Admin) request.getSession().getAttribute("admin");
		String path=request.getServletContext().getRealPath("");
		FileWrite file=new FileWrite(path);
		if(admin!=null) {
			file.logWrite("����Ա#"+admin.getAdmName()+"#�� "+getTime()+" "+op+"IDΪ"+id+info+".\n");
		}
		
	}
	   public String getTime(){
		     String id=null;
		     Date date=new Date();
		     SimpleDateFormat sf=
		    	 new SimpleDateFormat("yy��mm��dd��hh:mm:ss");
		     id=sf.format(date);
		     return id;
		    	
		    }

}
