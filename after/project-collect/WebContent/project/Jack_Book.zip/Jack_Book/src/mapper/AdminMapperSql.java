package mapper;

public class AdminMapperSql {
	
	String retrieveAuthor="select distinct a.*" + " from Book b,Author a,Stort s"
			+ " where a.autid=b.autid and s.stid=b.stid and (a.autName like ? or b.bName like ? or s.stName like ? or autPlace like ? or autSex like ? or autdate like ?)";

	String retrieveBook="select b.bphoto,b.bName,a.autName,s.stName, b.bStore,b.bPrice,b.bid,b.bSales"
			+ " from Book b,Author a,Stort s"
			+ " where b.autid=a.autid and b.stid=s.stid and (a.autName like ? or b.bName like ? or s.stName like ?)";
	
	String orderInfo="C:select u.uName,b.bName,o.ordTime,d.number,c.consName,c.consTel,c.consAddre,o.userdetail,o.ordSendState,o.ordPayState"
			+ " from User u,Orders o,Book b,Detail d,Consigness c "
			+ "where o.ordSendState=? and o.ordPayState=? and o.uid=u.uid and d.bid=b.bid and d.ordid=o.ordid and o.consid=c.consid";
	
	String showBook="select b.bphoto,b.bName,a.autName,s.stName, b.bStore,b.bPrice,b.bid,b.bSales from Book b,Author a,Stort s "
			+ "where b.stid=s.stid and b.autid=a.autid";
	
	String inveAlarm="select b.bphoto,b.bName,a.autName,s.stName, b.bStore,b.bPrice,b.bid " + "from Book b,Author a,Stort s "
			+ "where b.stid=s.stid and b.autid=a.autid and b.bStore<? ";
	
	String showStort="SELECT * FROM stort";
	
	String showOrder="select u.uName,o.* from Orders o,User u where o.uid=u.uid";
	
	String noPayment="select u.uName,o.* from Orders o,User u where o.uid=u.uid and o.ordPayState='δ����'";
	
	String noDelivery="select u.uName,o.* from Orders o,User u where o.uid=u.uid and o.ordPayState='�Ѹ���' and ordSendState='δ����'";
	
	String ubdcoJoin= "select u.uName,u.uTel,b.bphoto,b.bName,d.number,d.money,c.consName,c.consTel,c.consAddre,o.userdetail"
	+ " from User u,Book b,Detail d,Consigness c,Orders o "
	+ "where o.uid=u.uid and o.consid=c.consid and d.bid=b.bid and d.ordid=o.ordid and d.ordid=? ";
}
