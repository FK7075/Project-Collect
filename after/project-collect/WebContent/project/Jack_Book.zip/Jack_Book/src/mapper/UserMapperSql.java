package mapper;

public class UserMapperSql {
	
	String getPopularBook="SELECT b.bid,b.bname,a.autname,b.bprice,b.bdetail,b.bphoto "+
						  "FROM book b,author a "+
						  "WHERE b.autid=a.autid ORDER BY b.bsales DESC LIMIT 0,6";
	
	String showBookByStort="SELECT b.bid,b.bname,a.autname,b.bprice,b.bphoto "+
						   "FROM book b,author a ,stort s "+
						   "WHERE b.autid=a.autid AND b.stid=s.stid AND s.stid=? ORDER BY b.bsales DESC LIMIT 0,4";
	
	String showAllBook= "SELECT b.bid,b.bname,a.autname,b.bprice,b.bdetail,b.bphoto "+
				  	    "FROM book b,author a "+
				  	    "WHERE b.autid=a.autid LIMIT ?,12";
	
	String limitAuthor="SELECT * FROM author LIMIT ?,?";
	
	String updShopp="UPDATE shoppcart SET state=? WHERE uid=?";
	
	String search="SELECT b.bid,b.bname,a.autname,b.bprice,b.bdetail,b.bphoto "+
				  "FROM book b,author a,stort s "+
				  "WHERE b.stid=s.stid AND b.autid=a.autid AND bname LIKE ? AND autname LIKE ? AND stname like ?";
	
	String myOrders="select o.*,c.consName" + 
			" from Consigness c,User u,Orders o" + 
			" where o.uid=u.uid and o.consid=c.consid and u.uid=? and o.ordpaystate='δ����'";
	
	String payDetail="select o.*,c.consName" + 
			" from Consigness c,User u,Orders o" + 
			" where o.uid=u.uid and o.consid=c.consid and u.uid=? and o.ordpaystate='�Ѹ���' and o.ordsendstate='δ����'";
	
	String ordDetail="select b.bName,b.bPhoto,b.bPrice,d.money,d.number,o.ordid" + " FROM Detail d,Book b,Orders o"
			+ " where d.bid=b.bid and d.ordid=o.ordid and o.ordid=?";
	
	String sendOrder="select o.*,c.consName" + 
			" from Consigness c,User u,Orders o" + 
			" where o.uid=u.uid and o.consid=c.consid and u.uid=? and o.ordpaystate='�Ѹ���' and o.ordsendstate='�ѷ���'";
	
	String payOrdDetail="select b.bName,b.bPhoto,b.bPrice,d.money,d.number,o.ordid" + " FROM Detail d,Book b,Orders o"
			+ " where d.bid=b.bid and d.ordid=o.ordid and o.ordid=?";

}
