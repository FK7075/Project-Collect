package util;

import xfl.fk.sqldao.SqlCore;
import xfl.fk.sqldao.SqlCoreFactory;

public class CreateMySqlTables {

	public static void main(String[] args) {
		SqlCore sql=SqlCoreFactory.getSqlCore(true);
		Object[][] obj= {{"课外读物","✔"},{"科普读物","✔"},{"文学名著","✔"},{"网络小说","✔"}};
		sql.saveBatch("INSERT INTO stort(stName,isShow) VALUES(?,?)", obj);
	}

}
