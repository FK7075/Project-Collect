package util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class FileWrite {
	
	private File file;
	
	public FileWrite(String path) throws IOException{
		File file=new File(path+"/log.txt");
		if(!file.exists())
			file.createNewFile();
		this.file=file;
	}
	
	public void logWrite(String string) {
	try(PrintStream ps=new PrintStream(new BufferedOutputStream(new FileOutputStream(file,true)),true)){
		ps.println(string);
	}catch(IOException e) {
		e.printStackTrace();
	}
	}
}
