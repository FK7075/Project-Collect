package util;


import javax.servlet.http.HttpServletRequest;

import xfl.fk.servlet.LuckyWebContext;


/**
 * 工具类-用于处理重复操作
 * @author fk-7075
 *
 */
public class LucyUtil {
	
	private  HttpServletRequest request = LuckyWebContext.getCurrentContext().getRequest();

	
	/**
	 * 获得当前页码（从Url中拿到页码，出现异常则默认为第一页）
	 * @param message
	 * 页码在request中的name值
	 * @return
	 */
	public int getPage(String message) {
		try {
			return Integer.parseInt(request.getParameter(message));
		}catch (Exception e) {
			return 1;
		}
	}

	
}
