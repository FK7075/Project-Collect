package service;

import java.util.List;

import pojo.Author;
import pojo.Consigness;
import pojo.Notes;
import pojo.Orders;
import pojo.Stort;
import pojo.User;
import util.BookInfo;

public interface IUserService {
	
	public boolean addToCart(int uid, int bid);
	
	public void allChoose(String start);
	
	public List<Stort> allStort();
	
	public List<BookInfo> autToBooks(int autid);
	
	public boolean cancelOrder(int ordid);
	
	public boolean cartToOrder(User u, int[] shoppids, int[] numbers,String beizhu) ;
	
	public void changeState(int shopid);
	
	public void del(Class<?> c,int id);
	
	public Author getAuthorById(int autid);
	
	public List<Consigness> getConsigness(int uid);
	
	public <T> List<?> getList(T t);
	
	public List<Notes> getNotes();
	
	public Object getOne(Class<?> c, int id);
	
	public List<BookInfo> getPopularBook();
	
	public List<Stort> getShowStort();
	
	public User login(User user);
	
	public <T> boolean save(T t);
	
	public boolean register(User user);
	
	public List<BookInfo> search(String bName,String autName,String stName);
	
	public List<BookInfo> shoppCart(int uid);
	
	public List<Author> showAllAuthor(int page);
	
	public List<BookInfo> showAllBook(int page);
	
	public List<BookInfo> showBookByStort(int id);
	
	public List<BookInfo> stoToBooks(int stid);
	
	public <T> boolean update(T t);

	public List<Orders> myOrders(Integer uid);

	public List<Orders> payDetail(Integer uid);

	public List<BookInfo> ordDetail(Integer ordid);

	public List<BookInfo> payOrdDetail(Integer ordid);

	public List<Orders> sendOrder(Integer uid);

	
	
	

}
