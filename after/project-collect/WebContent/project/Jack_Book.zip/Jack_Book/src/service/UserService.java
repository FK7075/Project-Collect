package service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mapper.UserMapper;
import pojo.Author;
import pojo.Book;
import pojo.Consigness;
import pojo.Detail;
import pojo.Notes;
import pojo.Orders;
import pojo.ShoppCart;
import pojo.Stort;
import pojo.User;
import util.BookInfo;
import xfl.fk.annotation.Autowired;
import xfl.fk.annotation.Real;
import xfl.fk.annotation.Service;
import xfl.fk.servlet.LuckyWebContext;
import xfl.fk.servlet.Model;

@SuppressWarnings("all")
@Real("service.IUserService")
@Service
public class UserService implements IUserService {
	
	@Autowired
	private UserMapper mapper;
	
	@Autowired("model")
	private Model model;
	
	@Autowired("session")
	private HttpSession session;
	
	@Autowired("request")
	private HttpServletRequest request;
	
	@Autowired("response")
	private HttpServletResponse response;
	
	
	/**
	 * 显示最受欢迎的书本信息
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="getPopularBook方法查看了最受欢迎的图书")
	public List<BookInfo> getPopularBook() {
		return mapper.getPopularBook();
	}

	/**
	 * 显示美文
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="getNotes方法查看了美文")
	public List<Notes> getNotes() {
		return mapper.getPojos(new Notes());
	}

	/**
	 * 得到所有标记展示的类型
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="getShowStort方法查看了推荐类型")
	public List<Stort> getShowStort() {
		Stort st=new Stort();
		st.setIsShow("✔");
		return mapper.getPojos(st);
	}

	/**
	 * 得到该id对应类型下销量最好的四本书的信息
	 * @param id
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="showBookByStort方法查看了推荐类型下销量最好的四本书的信息")
	public List<BookInfo> showBookByStort(int id) {
		return mapper.showBookByStort(id);
	}
	
	/**
	 * 拿到书库在所有的类型
	 * @return
	 */
	public List<Stort> allStort() {
		return mapper.getPojos(new Stort());
		
	}
	
	/**
	 * 分页获得所有书本
	 * @param page
	 * 当前页码
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="showAllBook方法查看了所有书本")
	public List<BookInfo> showAllBook(int page) {
		User sessionUser=(User) model.getSessionAttribute("user");
		if(sessionUser!=null)
			return mapper.showAllBook((page-1)*sessionUser.getChangenum());
		else
			return mapper.showAllBook((page-1)*6);
	}
	
	/**
	 * 分页得到所有作者
	 * @param page
	 * 当前页码
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="showAllAuthor方法查看了所有作者")
	public List<Author> showAllAuthor(int page) {
		User sessionUser=(User) model.getSessionAttribute("user");
		if(sessionUser!=null)
			return mapper.limitAuthor((page-1)*sessionUser.getChangenum(), 9);
		else
			return mapper.limitAuthor((page-1)*5, 9);
	}
	
	/**
	 * 拿到该作者的所有图书
	 * @param autid
	 * 作者ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="autToBooks方法查看了某作者的所有书本")
	public List<BookInfo> autToBooks(int autid) {
		Author aut=new Author();
		aut.setAutid(autid);
		return mapper.boAuStJoin(new Book(), aut,new Stort());
	}
	
	/**
	 * 根据ID得到该作者的详细信息
	 * @param autid
	 * 作者ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="getAuthorById方法查看作者的详细信息")
	public Author getAuthorById(int autid) {
		return mapper.getPojoById(Author.class, autid);
	}
	
	/**
	 * 拿到该类型下的所有图书
	 * @param stid
	 * 类型ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="stoToBooks方法查看某类型下的所有图书")
	public List<BookInfo> stoToBooks(int stid) {
		Stort st=new Stort();
		st.setStid(stid);
		return mapper.boAuStJoin(new Book(), new Author(), st);
	}
	
	/**
	 * 用户登录（成功返回User对象，否则返回null）?
	 * @param user
	 * 包含用户名和密码的User对象
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="showBookByStort方法查看了推荐类型下销量最好的四本书的信息")
	public User login(User user) {
		if (mapper.getPojos(user).isEmpty())
			return null;
		else
			return mapper.getPojos(user).get(0);
	}
	
	/**
	 * 用户注册（成功返回true，用户名存在返回false）?
	 * @param user
	 * 包含用户注册信息的User对象
	 * @return
	 */
	public boolean register(User user) {
		User u = new User();
		u.setuName(user.getuName());
		if (!mapper.getPojos(u).isEmpty()) {
			return false;// 用户名已存在
		} else {
			return mapper.addPojo(user);
		}
	}
	
	/**
	 * 得到该用户的所有收货人
	 * @param uid
	 * 用户ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="getConsigness方法查看你的所有收货人")
	public List<Consigness> getConsigness(int uid) {
		Consigness con=new Consigness();
		con.setUid(uid);
		return mapper.getPojos(con);
	}
	
	/**
	 * 得到该用户的购物车信息
	 * @param uid
	 * 用户ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="shoppCart方法查看了您的购物车")
	public List<BookInfo> shoppCart(int uid){
		ShoppCart shop=new ShoppCart();
		shop.setUid(uid);
		return mapper.shopBoUsJoin(shop, new Book(), new User());
	}
	
	/**
	 * 单个选中或反选
	 * @param shopid
	 * 购物车ID
	 */
	@Real(classname="Log",method="log_u",parameter="changeState方法选中了一条购物车纪录")
	public void changeState(int shopid) {
		ShoppCart shopping=mapper.getPojoById(ShoppCart.class, shopid);
		if (shopping.getState().equals("未选中"))
			shopping.setState("已选中");
		else
			shopping.setState("未选中");
		mapper.updPojo(shopping);
	}
	
	/**
	 * 全选和反选
	 * @param start
	 */
	@Real(classname="Log",method="log_u",parameter="allChoose方法选中或者取消了所有购物车纪录")
	public void allChoose(String start) {
		User sessionUser=(User)model.getSessionAttribute("user");
		mapper.updShopp(start,sessionUser.getUid());
	}
	
	@Real(classname="Log",method="log_u",parameter="cartToOrder方法生成了一个订单")
	public boolean cartToOrder(User u, int[] shoppids, int[] numbers,String beizhu) {
		List<Detail> dl = xzCart(shoppids, numbers);//此明细记录的集合还缺少外键信息--订单ID
		if (numberOk(dl)) {//判断购物车中已选中的商品的购买数量是否超过库存
			Orders or=new Orders();//声明一个订单
			Double S=0.0;//用于存放订单的总金额
			SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");//设置日期格式
			String date=df.format(new Date());
			for (Detail det : dl) {//遍历明细信息，更新书本的信息（库存和销量）
				Book b =mapper.getPojoById(Book.class, det.getBid());//根据明细表中的书本外键得到对应书本的信息
				b.setbStore(b.getbStore()-det.getNumber());//更新这本书的库存
				b.setbSales(b.getbSales()+det.getNumber());//更新这本书的销量
				mapper.updPojo(b);//执行更新操作
				det.setMoney(b.getbPrice() * det.getNumber());// 小计(小计=购买数量*书本单价)
				S+=det.getMoney();//"小计"累加为"总金额"
			}
			//**********生成订单
			or.setConsid(u.getMyCons());//设置收货人
			or.setUid(u.getUid());//设置订单创建人
			or.setOrdPayState("未付款");//设置订单的初始‘付款状态’
			or.setOrdSendState("未发货");//设置订单的初始‘发货状态’
			or.setOrdTime(date);//设置订单的创建时间
			or.setOrdTotal(S);//设置订单的总金额
			or.setUserdetail(beizhu);//设置用户的备注信息
			mapper.addPojo(or);//保存订单
			//******************
			LuckyWebContext.getCurrentContext().getRequest().setAttribute("ordid", or.getOrdid());
			//*********生成订单明细并且删除购物车中对应的信息
			for (Detail det : dl) {//遍历明细记录并补充上订单ID
				det.setOrdid(or.getOrdid());//设置所属的订单
				mapper.addPojo(det);//生成明细
				ShoppCart shop=new ShoppCart();//订单生成后，删除购物车中对应的记录
				shop.setShopid(det.getShoppid());
				mapper.delPojo(shop);//删除购物车
			}
			//********************************************
			return true;
		} else {
			System.out.println("书本数量不够");
			return false;
		}
	}
	
	/**
	 * 购物车筛选生成并返回对应的明细记录(筛选出所有被选中的购物车记录)
	 * @param shoppids
	 * 购物车id数组
	 * @param numbers
	 * 购买数量数组
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="xzCart方法查看您的购物车")
	private List<Detail> xzCart(int[] shoppids, int[] numbers) {
		List<Detail> dl = new ArrayList<Detail>();//声明一个明细集合
		for (int i = 0; i < shoppids.length; i++) {//遍历传入的购物车ID并找出状态为"已选中"的
			ShoppCart sc = mapper.getPojoById(ShoppCart.class, shoppids[i]);//根据购物车ID拿到购物车信息
			if (sc.getState().equals("已选中")) {//状态判断（已选中的就加入到明细表中，为选中的不做操作）
				Detail det = new Detail();
				det.setBid(sc.getBid());// 书本id
				det.setNumber(numbers[i]);// 数量
				det.setShoppid(sc.getShopid());
				dl.add(det);
			}
		}
		return dl;//返回该用户由购物车中已选中的记录所组成的明细表记录集合
	}
	
	/**
	 * 判断筛选后的明细是否为空？且明细中对应的购买数量是否不大于书本的库存？
	 * @param detlist
	 * @return
	 */
	private boolean numberOk(List<Detail> detlist) {
		if(detlist.size()==0)//判断筛选后的明细是否为空
			return false;
		else {
			for(Detail det:detlist) {
				Book book= mapper.getPojoById(Book.class, det.getBid());
				if(det.getNumber()>book.getbStore())//判断明细中对应的购买数量是否不大于书本的库存
					return false;
			}
			return true;
		}
	}
	
	/**
	 * 取消订单，并还原书本信息
	 * @param ordid
	 * 订单ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="cancelOrder方法查取消了订单")
	public boolean cancelOrder(int ordid) {
		Detail de=new Detail();
		de.setOrdid(ordid);
		List<Detail> dl= mapper.getPojos(de);//得到该订单ID下的所有明细记录
		//**********还原书本库存和销量
		for (Detail detail : dl) {//遍历明细记录，根据每条记录中的书本ID找到并还原书本信息
			Book b= mapper.getPojoById(Book.class, detail.getBid());
			b.setbStore(b.getbStore()+detail.getNumber());//还原库存
			b.setbSales(b.getbSales()-detail.getNumber());//还原销量
			mapper.updPojo(b);//执行还原操作
		}
		//****************************
		mapper.delPojoById(Orders.class, ordid);//执行订单删除操作
		return true;
	}
	
	/**
	 * 多条件联合查询书本（书名+作者+类型）
	 * @param bName
	 * 书名
	 * @param autName
	 * 作者
	 * @param stName
	 * 类型
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="search方法进行了对书本的联合检索")
	public List<BookInfo> search(String bName,String autName,String stName){
		String b="%"+bName+"%";String a="%"+autName+"%";String s="%"+stName+"%";//模糊查询内容
		return mapper.search(b, a, s);
	}
	
	
	/**
	 * 添加书本到购物车（书本库存为0则无法添加）
	 * @param uid
	 * 用户ID
	 * @param bid
	 * 书本ID
	 * @return
	 */
	@Real(classname="Log",method="log_u",parameter="addToCart方法将书本添加到了购物车")
	public boolean addToCart(int uid, int bid) {
		Book book = mapper.getPojoById(Book.class, bid);//根据bid得到书本信息
		if (book.getbStore() > 0) {//判断库存是否大于0
			ShoppCart shop = new ShoppCart();//声明购物车
			shop.setBid(bid);//设置书本ID'bid'
			shop.setState("未选中");//设置默认状态为‘未选中’
			shop.setUid(uid);//设置用户ID'uid'
			mapper.addPojo(shop);//执行添加操作
			return true;
		} else {
			return false;//库存为0，如法添加到购物车
		}
	}
	
	public <T> boolean save(T t) {
		return mapper.addPojo(t);
	}
	
	public <T> List<?> getList(T t) {
		return mapper.getPojos(t);
	}
	
	public <T> boolean update(T t) {
		return mapper.updPojo(t);
	}
	
	public void del(Class<?> c,int id) {
		mapper.delPojoById(c, id);
	}
	
	public Object getOne(Class c, int id) {
		return mapper.getPojoById(c, id);
	}

	@Override
	public List<Orders> myOrders(Integer uid) {
		return mapper.myOrders(uid);
	}

	public List<Orders> payDetail(Integer uid) {
		return mapper.payDetail(uid);
	}

	public List<BookInfo> ordDetail(Integer ordid) {
		return mapper.ordDetail(ordid);
	}

	public List<BookInfo> payOrdDetail(Integer ordid) {
		return mapper.payOrdDetail(ordid);
	}

	public List<Orders> sendOrder(Integer uid) {
		return mapper.sendOrder(uid);
	}
	

}
