package service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import mapper.AdminMapper;
import pojo.Admin;
import pojo.Author;
import pojo.Book;
import pojo.Consigness;
import pojo.Detail;
import pojo.Orders;
import pojo.Stort;
import pojo.User;
import util.BookInfo;
import util.DetailInfo;
import util.OrderInfo;
import xfl.fk.annotation.Autowired;
import xfl.fk.annotation.Real;
import xfl.fk.annotation.Service;

@SuppressWarnings("all")
@Real("service.IAdminService")
@Service
public class AdminService implements IAdminService {
	
//	@Autowired
//	private SqlDao sqlDao;
	
	@Autowired
	private AdminMapper mapper;
	
	
	/**
	 * 用户登录
	 * @param admin
	 * @return
	 */
	public Admin islogin(Admin admin) {
		if(mapper.getPojos(admin).isEmpty())
			return null;
		else
			return mapper.getPojos(admin).get(0);
	}
	
	/**
	 * 得到数据统计的信息
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="statistical方法查看了数剧统计")
	public List<Object> statistical(){
		List<Object> intlist=new ArrayList<Object>();//声明一个存放数据的Object集合
		List<Book> bl=mapper.getPojos(new Book());//得到所有的书本
		List<User> ul=mapper.getPojos(new User());//得到所有的用户
		List<Detail> dl=mapper.getPojos(new Detail()); //得到所有的明细
		Long yh=(long) 0;//存放总用户量
		Double dd=0.0;//存放总收入
		Long xl=(long) 0;//存放总销量
		yh=(long) ul.size();
		for (Book book : bl) {
			xl+=book.getbSales();//销量累加求和得到总销量
		}
		for (Detail detail : dl) {
			dd+=detail.getMoney();//小计累计求和得到总收入
		}
		intlist.add(xl);
		intlist.add(dd);
		intlist.add(yh);
		return intlist;
	}
	
	/**
	 * 分页显示所有书本
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="showBook方法查看了所有书本")
	public List<BookInfo> showBook(){
		return mapper.showBook();
	}
	
	/**
	 * 删除图书，并连带删除书本图片
	 * @param id
	 * @param path
	 * @return
	 */
	@Real(classname="Log",method="admin_del",parameter={"#id","删除了","一本图书"})
	public boolean delBook(int id,String path) {
		Book book=mapper.getPojoById(Book.class, id);
		path+=book.getbPhoto();
		File file=new File(path);
		if(file.exists())
			file.delete();
		return mapper.delPojoById(Book.class, id);
	}
	
	/**
	 * 删除作者，并连带删除作者图片
	 * @param id
	 * @param path
	 * @return
	 */
	@Real(classname="Log",method="admin_del",parameter={"#id","删除了","一名作者以及该作者名下的所有图书"})
	public boolean delAuthor(int id,String path) {
		Author author=mapper.getPojoById(Author.class, id);
		path+=author.getAutPor();
		File file=new File(path);
		if(file.exists())
			file.delete();
		return mapper.delPojoById(Author.class, id);
	}
	
	/**
	 * 删除管理员，并连带删除图片
	 * @param id
	 * @param path
	 * @return
	 */
	@Real(classname="Log",method="admin_del",parameter={"#id","删除了","一名管理员"})
	public boolean delAdmin(int id,String path) {
		Admin admin=mapper.getPojoById(Admin.class, id);
		path+=admin.getAdmPor();
		File file=new File(path);
		if(file.exists())
			file.delete();
		return mapper.delPojoById(Admin.class, id);
	}
	
	/**
	 * 得到作者列表和类型列表
	 * @return
	 */
	public List<List<?>> showAddBook(){
		List<List<?>> list=new ArrayList();
		List<Author> la=mapper.getPojos(new Author());
		List<Stort> ls=mapper.getPojos(new Stort());
		list.add(la);
		list.add(ls);
		return list;
	}
	/**
	 * 保存图书
	 * @param book
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="addBook方法添加了一本图书")
	public boolean addBook(Book book) {
		return mapper.addPojo(book);
	}
	
	/**
	 * 保存一条记录
	 * @param book
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="add方法添加了一条记录")
	public boolean add(Object obj) {
		return mapper.addPojo(obj);
	}
	
	/**
	 * 得到一本书的详细信息
	 */
	@Real(classname="Log",method="log_a",parameter="getBook方法查看了书本的详细信息")
	public BookInfo getBook(int id) {
		Book book=new Book();
		book.setBid(id);
		return mapper.boAuStJoin(book, new Author(), new Stort()).get(0);
	}
	
	/**
	 * 得到一本图书
	 * @param id
	 * @return
	 */
	public Book getOneBook(int id) {
		return mapper.getPojoById(Book.class, id);
	}
	
	/**
	 * 得到一条记录
	 * @param c
	 * @param id
	 * @return
	 */
	public Object getOne(Class<?> c,int id) {
		return mapper.getPojoById(c, id);
	}
	
	/**
	 * 更新一本图书
	 * @param book
	 * @return
	 */
	public boolean updBook(Book book) {
		return mapper.updPojo(book);
	}
	
	/**
	 * 更新管理员
	 * @param book
	 * @return
	 */
	public boolean updAdmin(Admin admin) {
		return mapper.updPojo(admin);
	}
	/**
	 * 分页_库存警报
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="inveAlarm方法查看库存警报")
	public List<BookInfo> inveAlarm(int sto){
		return mapper.inveAlarm(sto);
	}
	
	/**
	 * 分页_类型
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="showStort方法查看了所有书本类型")
	public List<Stort> showStort(){
		return mapper.showStort();
	}
	
	/**
	 * 分页_用户
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="allUser方法查看了所有用户")
	public List<User> allUser(){
		return mapper.getPojos(new User());
	}
	
	/**
	 * 分页_用户
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="allAdmin方法查看了所有管理员")
	public List<Admin> allAdmin(){
		return mapper.getPojos(new Admin());
	}
	
	/**
	 * 分页_作者
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="showAuthor方法查看了所有作者")
	public List<Author> showAuthor(){
		return mapper.getPojos(new Author());
	}
	
	/**
	 * 分页_订单
	 * @param pi
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="showOrder方法查看了所有订单")
	public List<OrderInfo> showOrder(){
		return mapper.showOrder();
	}
	/**
	 * 删除纪录
	 * @param c
	 * @param id
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="del方法删除了一条记录")
	public boolean del(Class<?> c,int id) {
		return mapper.delPojoById(c, id);
	}
	
	/**
	 * 添加书本类型
	 * @param stname
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="addStortIsOk方法添加了一个书本类型")
	public boolean addStortIsOk(String stname) {
		Stort st=new Stort();
		st.setStName(stname);
		if(mapper.getPojos(st).isEmpty()) {
			st.setIsShow("__");
			return mapper.addPojo(st);
		}else {
			return false;
		}
	}
	
	/**
	 * 更新一条记录
	 * @param obj
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="upd方法更新了一条数据")
	public boolean upd(Object obj) {
		return mapper.updPojo(obj);
	}
	
	/**
	 * 单击'✔'变为'__',单击'__'变为'✔'
	 * @param id
	 */
	@Real(classname="Log",method="log_a",parameter="isShowStrot方法改变了前台要展示的类型")
	public void isShowStrot(int id) {
		Stort st=mapper.getPojoById(Stort.class, id);
		if("✔".equals(st.getIsShow())) {
			st.setIsShow("__");
			mapper.updPojo(st);
		}else {
			Stort stort=new Stort();
			stort.setIsShow("✔");
			if(mapper.getPojos(stort).size()<4) {
				st.setIsShow("✔");
				mapper.updPojo(st);
			}
		}
		
	}
	

	
	/**
	 * 查看明细
	 */
	@Real(classname="Log",method="log_a",parameter="showDetail方法查看了订单的明细")
	public List<DetailInfo> showDetail(int id){
		return mapper.ubdcoJoin(id);
	}
	
	/**
	 * 未付款的所有订单
	 */
	@Real(classname="Log",method="log_a",parameter="noPayment方法查看了未付款的所有订单")
	public List<OrderInfo> noPayment(){
		return mapper.noPayment();
	}
	
	/**
	 * 已付款但未发货的所有订单
	 */
	@Real(classname="Log",method="log_a",parameter="noDelivery方法查看已付款但未发货的所有订单")
	public List<OrderInfo> noDelivery(){
		return mapper.noDelivery();
	}
	
	/**
	 * 删除订单，还原数据
	 * @param id
	 */
	@Real(classname="Log",method="admin_del",parameter={"#id","删除了","一条未付款的订单"})
	public void delOrder(int id) {
		Detail de=new Detail();
		de.setOrdid(id);
		List<Detail> dl= mapper.getPojos(de);
		for (Detail detail : dl) {
			Book b=mapper.getPojoById(Book.class, detail.getBid());
			b.setbStore(b.getbStore()+detail.getNumber());
			b.setbSales(b.getbSales()-detail.getNumber());
			mapper.updPojo(b);
		}
		mapper.delPojoById(Orders.class, id);
	}
	
	/**
	 * 添加管理员
	 * @param admin
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="addAdmin方法添加了一名管理员")
	public boolean addAdmin(Admin admin) {
		Admin a=new Admin();
		a.setAdmName(admin.getAdmName());
		if(mapper.getPojos(a).isEmpty()) {
			return mapper.addPojo(admin);
		}else {
			return false;
		}
	}
	
	/**
	 * 根据书名，类型名，作者姓名，作者国籍，作者性别，作者出生日期查作者
	 * @param info
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="retrieveAuthor方法搜索了一名作者")
	public List<Author> retrieveAuthor(String info) {
		String xx = "%" + info + "%";
		return mapper.retrieveAuthor(xx,xx,xx,xx,xx);
	}
	
	/**
	 * 根据书名，作者，类型查书本
	 * @param info
	 * @return
	 */
	@Real(classname="Log",method="log_a",parameter="retrieveBook方法搜索了某本书")
	public List<BookInfo> retrieveBook(String info){
		String xx = "%" + info + "%";
		return mapper.retrieveBook(xx, xx, xx);
	}
	/**
	 * 生成Excel表格
	 */
	@Real(classname="Log",method="log_a",parameter="excel方法将订单导出为excel文件")
	public void excel(String path) throws IOException {
		List<OrderInfo> all=mapper.orderInfo(null,null);;//全部订单
		List<OrderInfo> yes=mapper.orderInfo("已发货",null);//已发货
		List<OrderInfo> no=mapper.orderInfo("未发货","已付款");//未发货
		// 创建Excel工作薄
		HSSFWorkbook workbook = new HSSFWorkbook();
	    // 创建"全部订单"的工作表
	    HSSFSheet sheet1= workbook.createSheet("全部订单");
	    //写入表头
	    HSSFRow rows1 = sheet1.createRow(0);
	   	rows1.createCell(0).setCellValue("订单发起人");
	   	rows1.createCell(1).setCellValue("创建时间");
	   	rows1.createCell(2).setCellValue("商品名称");
	   	rows1.createCell(3).setCellValue("购买数量");
	   	rows1.createCell(4).setCellValue("收货人姓名");
	   	rows1.createCell(5).setCellValue("收货人电话");
	   	rows1.createCell(6).setCellValue("收货人地址");
	   	rows1.createCell(7).setCellValue("用户备注");
	   	rows1.createCell(8).setCellValue("发货状态");
	   	rows1.createCell(9).setCellValue("付款状态");
	   	if(all.size()!=0) {
	    for(int row=0;row<all.size();row++) {
	    	// 向工作表中添加数剧
	    	 HSSFRow rows = sheet1.createRow(row+1);
	    	 rows.createCell(0).setCellValue(all.get(row).getuName());
	    	 rows.createCell(1).setCellValue(all.get(row).getOrdTime());
	    	 rows.createCell(2).setCellValue(all.get(row).getbName());
	    	 rows.createCell(3).setCellValue(all.get(row).getNumber());
	    	 rows.createCell(4).setCellValue(all.get(row).getConsName());
	    	 rows.createCell(5).setCellValue(all.get(row).getConsTel());
	    	 rows.createCell(6).setCellValue(all.get(row).getConsAddre());
	    	 rows.createCell(7).setCellValue(all.get(row).getUserdetail());
	    	 rows.createCell(8).setCellValue(all.get(row).getOrdSendState());
	    	 rows.createCell(9).setCellValue(all.get(row).getOrdPayState());
	    }
	   	}
	    // 创建"已完成订单"的工作表
	    HSSFSheet sheet2= workbook.createSheet("已完成订单");
	    HSSFRow rows2 = sheet2.createRow(0);
	   	rows2.createCell(0).setCellValue("订单发起人");
	   	rows2.createCell(1).setCellValue("创建时间");
	   	rows2.createCell(2).setCellValue("商品名称");
	   	rows2.createCell(3).setCellValue("购买数量");
	   	rows2.createCell(4).setCellValue("收货人姓名");
	   	rows2.createCell(5).setCellValue("收货人电话");
	   	rows2.createCell(6).setCellValue("收货人地址");
	   	rows2.createCell(7).setCellValue("用户备注");
	   	rows2.createCell(8).setCellValue("发货状态");
	   	rows2.createCell(9).setCellValue("付款状态");
	   	if(yes.size()!=0) {
	    for(int row=0;row<yes.size();row++) {
	    	// 向工作表中添加数剧
	    	 HSSFRow rows = sheet2.createRow(row+1);
	    	 rows.createCell(0).setCellValue(yes.get(row).getuName());
	    	 rows.createCell(1).setCellValue(yes.get(row).getOrdTime());
	    	 rows.createCell(2).setCellValue(yes.get(row).getbName());
	    	 rows.createCell(3).setCellValue(yes.get(row).getNumber());
	    	 rows.createCell(4).setCellValue(yes.get(row).getConsName());
	    	 rows.createCell(5).setCellValue(yes.get(row).getConsTel());
	    	 rows.createCell(6).setCellValue(yes.get(row).getConsAddre());
	    	 rows.createCell(7).setCellValue(yes.get(row).getUserdetail());
	    	 rows.createCell(8).setCellValue(yes.get(row).getOrdSendState());
	    	 rows.createCell(9).setCellValue(yes.get(row).getOrdPayState());
	    }
	   	}
	    // 创建"已付款未发货订单"的工作表
	    HSSFSheet sheet3= workbook.createSheet("已付款未发货订单");
	    HSSFRow rows3 = sheet3.createRow(0);
	   	rows3.createCell(0).setCellValue("订单发起人");
	   	rows3.createCell(1).setCellValue("创建时间");
	   	rows3.createCell(2).setCellValue("商品名称");
	   	rows3.createCell(3).setCellValue("购买数量");
	   	rows3.createCell(4).setCellValue("收货人姓名");
	   	rows3.createCell(5).setCellValue("收货人电话");
	   	rows3.createCell(6).setCellValue("收货人地址");
	   	rows3.createCell(7).setCellValue("用户备注");
	   	rows3.createCell(8).setCellValue("发货状态");
	   	rows3.createCell(9).setCellValue("付款状态");
	   	if(no.size()!=0) {
	    for(int row=0;row<no.size();row++) {
	    	// 向工作表中添加数剧
	    	 HSSFRow rows = sheet3.createRow(row+1);
	    	 rows.createCell(0).setCellValue(no.get(row).getuName());
	    	 rows.createCell(1).setCellValue(no.get(row).getOrdTime());
	    	 rows.createCell(2).setCellValue(no.get(row).getbName());
	    	 rows.createCell(3).setCellValue(no.get(row).getNumber());
	    	 rows.createCell(4).setCellValue(no.get(row).getConsName());
	    	 rows.createCell(5).setCellValue(no.get(row).getConsTel());
	    	 rows.createCell(6).setCellValue(no.get(row).getConsAddre());
	    	 rows.createCell(7).setCellValue(no.get(row).getUserdetail());
	    	 rows.createCell(8).setCellValue(no.get(row).getOrdSendState());
	    	 rows.createCell(9).setCellValue(no.get(row).getOrdPayState());
	    }
	   	}
	      File xlsFile = new File(path+"/order.xls");
	      FileOutputStream xlsStream = new FileOutputStream(xlsFile);
	      workbook.write(xlsStream);
	}

	public <T> List<T> getList(T t) {
		return mapper.getPojos(t);
	}
	
}
