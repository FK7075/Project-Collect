package service;

import java.io.IOException;
import java.util.List;

import pojo.Admin;
import pojo.Author;
import pojo.Book;
import pojo.Stort;
import pojo.User;
import util.BookInfo;
import util.DetailInfo;
import util.OrderInfo;

public interface IAdminService {
	
	public boolean add(Object obj);
	
	public boolean addAdmin(Admin admin);
	
	public boolean addBook(Book book);
	
	public boolean addStortIsOk(String stname);
	
	public List<Admin> allAdmin();
	
	public List<User> allUser();
	
	public boolean del(Class<?> c,int id);
	
	public boolean delAdmin(int id,String path);
	
	public boolean delAuthor(int id,String path);
	
	public boolean delBook(int id,String path);
	
	public void delOrder(int id);
	
	public void excel(String path) throws IOException;
	
	public BookInfo getBook(int id);
	
	public <T> List<T> getList(T t);
	
	public Object getOne(Class<?> c,int id);
	
	public Book getOneBook(int id);
	
	public List<BookInfo> inveAlarm(int sto);
	
	public Admin islogin(Admin admin);
	
	public void isShowStrot(int id) ;
	
	public List<OrderInfo> noDelivery();
	
	public List<OrderInfo> noPayment();
	
	public List<Author> retrieveAuthor(String info) ;
	
	public List<BookInfo> retrieveBook(String info);
	
	public List<List<?>> showAddBook();
	
	public List<Author> showAuthor();
	
	public List<BookInfo> showBook();
	
	public List<DetailInfo> showDetail(int id);
	
	public List<OrderInfo> showOrder();
	
	public List<Stort> showStort();
	
	public List<Object> statistical();
	
	public boolean upd(Object obj);
	
	public boolean updAdmin(Admin admin);
	
	public boolean updBook(Book book);
	
	
	
	

}
